# violence_train > 2024-05-13 5:43pm
https://universe.roboflow.com/test-hitoh/violence_train

Provided by a Roboflow user
License: CC BY 4.0

