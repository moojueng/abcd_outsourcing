#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>

#include "lexsyn.h"
#include "util.h"
#include "dynarray.h"
#include "token.h"

#define CD 1
#define EXIT 2
#define SETENV 3
#define UNSETENV 4
#define NOTBUILTIN 0

/* Global Variables */
int builtInState = NOTBUILTIN;

/* Function prototypes */
void createTokenArray(DynArray_T oTokens, char ***tokenArray, int *tokenCount);
int handleRedir(char **args, int index, int direction);
int exec_builtIn(DynArray_T oTokens);
int exec_nonBuiltIn(DynArray_T oTokens);
static void shellHelper(const char *inLine);
void handleSigQuit(int sig);
void handleSigAlarm(int sig);
void executeCommandsFromIshrc();

int main() {
    /* Handle Signals */
    sigset_t sSet;
    sigemptyset(&sSet);
    sigaddset(&sSet, SIGINT);
    sigaddset(&sSet, SIGQUIT);
    sigaddset(&sSet, SIGALRM);
    sigprocmask(SIG_UNBLOCK, &sSet, NULL);

    struct {
        int signum;
        void (*handler)(int);
    } signalHandlers[] = {
        {SIGINT, SIG_IGN},
        {SIGQUIT, handleSigQuit},
        {SIGALRM, handleSigAlarm},
    };

    for (size_t i = 0; i < sizeof(signalHandlers) / sizeof(signalHandlers[0]); i++) {
        void (*p)(int);
        p = signal(signalHandlers[i].signum, signalHandlers[i].handler);
        assert(p != SIG_ERR);
    }

    char curDir[MAX_LINE_SIZE];
    if (getcwd(curDir, sizeof(curDir)) == NULL) {
        return 1;
    }
    char *homeDir = getenv("HOME");

    chdir(homeDir);
    executeCommandsFromIshrc();
    chdir(curDir);

    while (1) {
        printf("%% ");
        fflush(stdout);

        char command[MAX_LINE_SIZE];
        if (fgets(command, MAX_LINE_SIZE, stdin) == NULL) {
            printf("\n");
            fflush(stdout);
            exit(0);
        }

        if (strcmp(command, "\n") == 0) {
            continue;
        }

        shellHelper(command);
    }

    return 0;
}

void createTokenArray(DynArray_T oTokens, char ***tokenArray, int *tokenCount) {
    *tokenCount = DynArray_getLength(oTokens);
    *tokenArray = calloc(*tokenCount, sizeof(char *));

    for (int i = 0; i < *tokenCount; i++) {
        struct Token *token = (struct Token *)DynArray_get(oTokens, i);
        (*tokenArray)[i] = strdup(token->pcValue);
    }
}

int handleRedir(char **args, int index, int direction) {
    int child_pid = fork();
    if (child_pid < 0) {
        fprintf(stderr, "./ish: failed to fork\n");
        return -1;
    }

    if (child_pid == 0) {
        FILE *fd;
        const char *mode;

        switch (direction) {
        case TOKEN_REDIN: {
            mode = "r";
            break;
        }
        case TOKEN_REDOUT: {
            mode = "w+";
            break;
        }
        default: {
            fprintf(stderr, "./ish: Invalid direction\n");
            return -1;
        }
        }

        fd = fopen(args[index + 1], mode);

        if (fd == NULL) {
            fprintf(stderr, "./ish: No such file or directory\n");
            return -1;
        }

        dup2(fileno(fd), direction == TOKEN_REDIN ? 0 : 1);
        fclose(fd);

        execvp(args[0], args);
        perror(args[0]);
        exit(EXIT_FAILURE);
    } else {
        waitpid(child_pid, NULL, 0);
    }

    return 0;
}

int exec_builtIn(DynArray_T oTokens) {
    char **commandArray;
    int tokenCount;
    createTokenArray(oTokens, &commandArray, &tokenCount);

    switch (builtInState) {
    case CD: {
        if (tokenCount == 1 || tokenCount == 2) {
            const char *directory;
            if (tokenCount == 1) {
                directory = getenv("HOME");
            } else {
                directory = commandArray[1];
            }

            if (chdir(directory) == -1) {
                perror(commandArray[0]);
            }
        } else {
            fprintf(stderr, "./ish: cd takes one parameter\n");
        }
        free(commandArray);
        break;
    }
    case EXIT: {
        if (tokenCount == 1) {
            printf("\n");
            fflush(stdout);
            exit(0);
        } else {
            fprintf(stderr, "./ish: exit does not take any parameters");
        }
        free(commandArray);
        break;
    }
    case SETENV: {
        if (tokenCount < 2 || tokenCount > 3) {
            fprintf(stderr, "./ish: setenv takes one or two parameters\n");
            break;
        }

        int result = setenv(commandArray[1], (tokenCount == 2) ? "" : commandArray[2], 1);
        if (result == -1) {
            perror(commandArray[0]);
        } else if (tokenCount == 2) {
            fprintf(stderr, "./ish: setenv takes one or two parameters\n");
        }

        free(commandArray);
        break;
    }
    case UNSETENV: {
        if (tokenCount == 2) {
            if (unsetenv(commandArray[1]) == -1) {
                perror(commandArray[0]);
            }
        } else {
            fprintf(stderr, "./ish: unsetenv takes one parameter\n");
        }
        free(commandArray);
        break;
    }
    default: {
        free(commandArray);
        break;
    }
    }
    return 0;
}

int exec_nonBuiltIn(DynArray_T oTokens) {
    struct Token *curToken;
    int tokenCount = DynArray_getLength(oTokens);
    char *argv[tokenCount + 1];

    for (int i = 0; i < tokenCount; i++) {
        curToken = (struct Token *)DynArray_get(oTokens, i);
        argv[i] = curToken->pcValue;
    }

    for (int i = 0; i < tokenCount; i++) {
        curToken = (struct Token *)DynArray_get(oTokens, i);
        if (curToken->eType == TOKEN_REDIN || curToken->eType == TOKEN_REDOUT) {
            handleRedir(argv, i, curToken->eType);
            return 0;
        }
    }

    int pID = fork();

    if (pID < 0) {
        fprintf(stderr, "./ish: failed to fork\n");
    } else if (pID == 0) { // In child process
        char *args[tokenCount + 1];
        for (int i = 0; i < tokenCount; i++) {
            struct Token *argvArray = (struct Token *)DynArray_get(oTokens, i);
            args[i] = argvArray->pcValue;
        }
        args[tokenCount] = NULL; // NULL terminator required by execvp

        execvp(args[0], args);
        perror(args[0]);
        exit(EXIT_FAILURE);
    } else { // In parent process
        wait(NULL);
    }
    fflush(NULL);
    return 0;
}

static void shellHelper(const char *inLine) {
    DynArray_T oTokens;

    enum LexResult lexcheck;
    enum SyntaxResult syncheck;
    enum BuiltinType btype;

    oTokens = DynArray_new(0);
    if (oTokens == NULL) {
        fprintf(stderr, "Cannot allocate memory\n");
        exit(EXIT_FAILURE);
    }

    lexcheck = lexLine(inLine, oTokens);
    switch (lexcheck) {
    case LEX_SUCCESS:
        if (DynArray_getLength(oTokens) == 0)
            return;

        dumpLex(oTokens);

        syncheck = syntaxCheck(oTokens);
        if (syncheck == SYN_SUCCESS) {
            btype = checkBuiltin(DynArray_get(oTokens, 0));

            switch (btype) {
            case B_CD: {
                builtInState = CD;
                break;
            }
            case B_EXIT: {
                builtInState = EXIT;
                break;
            }
            case B_SETENV: {
                builtInState = SETENV;
                break;
            }
            case B_UNSETENV: {
                builtInState = UNSETENV;
                break;
            }
            default: {
                builtInState = NOTBUILTIN;
                break;
            }
            }
            if (builtInState != 0) {
                exec_builtIn(oTokens);
            } else {
                exec_nonBuiltIn(oTokens);
            }
        } else if (syncheck == SYN_FAIL_NOCMD)
            errorPrint("Missing command name", FPRINTF);
        else if (syncheck == SYN_FAIL_MULTREDOUT)
            errorPrint("Multiple redirection of standard out", FPRINTF);
        else if (syncheck == SYN_FAIL_NODESTOUT)
            errorPrint("Standard output redirection without file name", FPRINTF);
        else if (syncheck == SYN_FAIL_MULTREDIN)
            errorPrint("Multiple redirection of standard input", FPRINTF);
        else if (syncheck == SYN_FAIL_NODESTIN)
            errorPrint("Standard input redirection without file name", FPRINTF);
        else if (syncheck == SYN_FAIL_INVALIDBG)
            errorPrint("Invalid use of background", FPRINTF);
        break;

    case LEX_QERROR:
        errorPrint("Unmatched quote", FPRINTF);
        break;

    case LEX_NOMEM:
        errorPrint("Cannot allocate memory", FPRINTF);
        break;

    case LEX_LONG:
        errorPrint("Command is too large", FPRINTF);
        break;

    default:
        errorPrint("lexLine needs to be fixed", FPRINTF);
        exit(EXIT_FAILURE);
    }
}

void handleSigQuit(int sig) {
    if (getpid() == 0) {
        exit(0);
    } else {
        fprintf(stdout, "\nType Ctrl-\\ again within 5 seconds to exit.\n");
        fflush(stdout);
        alarm(5);
        signal(SIGQUIT, handleSigQuit);
    }
}

void handleSigAlarm(int sig) {
    signal(SIGQUIT, handleSigQuit);
    return;
}

void executeCommandsFromIshrc() {
    char command[MAX_LINE_SIZE];
    FILE *ishrc = fopen(".ishrc", "r");
    if (ishrc != NULL) {
        while (fgets(command, MAX_LINE_SIZE, ishrc) != NULL) {
            printf("%% %s", command);
            fflush(stdout);
            shellHelper(command);
        }
        fclose(ishrc);
    }
    fflush(NULL);
}

